var laptop={
    Name: "Asus",
    Model: "Tuf F15",
    processor: "i5",
    Price: 58000
}
console.log(car.Name);
console.log(car.Model);
console.log(car.processor);
console.log(car.Price);