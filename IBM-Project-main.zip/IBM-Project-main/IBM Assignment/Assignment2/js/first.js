let name = "Gokul";
let i = 0;
while(i < name.length){
    console.log(name[i]);
    i++;
}