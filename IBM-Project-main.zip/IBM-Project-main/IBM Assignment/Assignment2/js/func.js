function wish(name){
    console.log("Good morning !" + name);
}
var name = prompt("enter the name")
wish(name);
