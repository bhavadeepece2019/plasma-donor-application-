var x = 10;
function square(num1){
    x=30;
    return num1*num1;
}
console.log(square(9));
console.log(x);