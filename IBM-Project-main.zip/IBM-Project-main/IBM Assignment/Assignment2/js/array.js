let a = [1,,3,,4,5];
let i;
let sum = 0;
for(i=0;i<a.length;i++){
    console.log(a[i]);
    sum += a[i];
}
console.log(`Sum of elements in array is ${sum}`);

let fruit = ["Apple","Orange","Pineapple"];
for(fruits of fruit){
    console.log(fruits);
}