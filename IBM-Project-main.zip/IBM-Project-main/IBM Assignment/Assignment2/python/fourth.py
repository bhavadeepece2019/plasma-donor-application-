mark = [89,90,100,78,90]
sum = 0
for i in mark:
    sum += i
print(sum)
