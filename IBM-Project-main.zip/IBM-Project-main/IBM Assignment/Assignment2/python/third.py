for  i in range(5):
    print(i)
marks=[95,97,82]
print(marks[1])
marks.append(100)
print(marks)
marks.insert(0,67)
print(marks)
marks.clear()
print(marks)
