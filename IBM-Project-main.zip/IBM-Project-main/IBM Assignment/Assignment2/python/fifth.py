def print_sum(first,second,opr):

    if opr == "sum":
        result = first+second
        print(result)
    elif opr == "mul":
        result = first * second
        print(result)
    elif opr == "sub":
        result = first - second
        print(result)
    elif opr == "div":
        result = first * second
        print(result)

    

print_sum(5,6)
print_sum(77,88)


